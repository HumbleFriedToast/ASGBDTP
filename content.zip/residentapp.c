// sysmon.c - Enhanced System Process Monitor & Modifier
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/resource.h>
#include <sched.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <sys/utsname.h>
#include <sys/sysinfo.h>
#include <limits.h>

#define BUFFER_SIZE 4096

// ANSI Color Codes
#define RESET       "\033[0m"
#define BOLD        "\033[1m"
#define DIM         "\033[2m"
#define CYAN        "\033[36m"
#define BRIGHT_CYAN "\033[96m"
#define GREEN       "\033[32m"
#define BRIGHT_GREEN "\033[92m"
#define YELLOW      "\033[33m"
#define BRIGHT_YELLOW "\033[93m"
#define RED         "\033[31m"
#define BRIGHT_RED  "\033[91m"
#define MAGENTA     "\033[35m"
#define BRIGHT_MAGENTA "\033[95m"
#define BLUE        "\033[34m"
#define BRIGHT_BLUE "\033[94m"
#define WHITE       "\033[37m"
#define BRIGHT_WHITE "\033[97m"

// Structure to hold process information
typedef struct {
    pid_t pid;
    pid_t ppid;
    pid_t pgid;
    pid_t sid;
    uid_t uid;
    gid_t gid;
    int priority;
    int nice;
    int policy;
    char state;
    unsigned long utime;
    unsigned long stime;
    long num_threads;
    unsigned long vsize;
    long rss;
    
    // Resource limits
    struct rlimit rlim_cpu;
    struct rlimit rlim_fsize;
    struct rlimit rlim_nofile;
    struct rlimit rlim_stack;
    
    // Working directory
    char cwd[PATH_MAX];
    
    // System info
    char hostname[256];
} ProcessInfo;

// Read process status from /proc
int read_proc_stat(ProcessInfo* info) {
    char path[256];
    FILE* fp;
    
    snprintf(path, sizeof(path), "/proc/%d/stat", info->pid);
    fp = fopen(path, "r");
    if (!fp) return -1;

    fscanf(fp, "%*d %*s %c %d %d %d %*d %*d %*u %*u %*u %*u %*u %lu %lu %*d %*d %d %ld %*d %*d %*u %lu %ld",
           &info->state, &info->ppid, &info->pgid, &info->sid,
           &info->utime, &info->stime, &info->priority, &info->num_threads,
           &info->vsize, &info->rss);
    
    fclose(fp);
    return 0;
}

// Read process status info
int read_proc_status(ProcessInfo* info) {
    char path[256];
    char line[256];
    FILE* fp;
    
    snprintf(path, sizeof(path), "/proc/%d/status", info->pid);
    fp = fopen(path, "r");
    if (!fp) return -1;

    while (fgets(line, sizeof(line), fp)) {
        if (sscanf(line, "Uid:\t%d", &info->uid) == 1) continue;
        if (sscanf(line, "Gid:\t%d", &info->gid) == 1) continue;
    }
    
    fclose(fp);
    return 0;
}

// Get current process information
void get_process_info(ProcessInfo* info) {
    info->pid = getpid();
    info->ppid = getppid();
    info->pgid = getpgid(0);
    info->sid = getsid(0);
    info->uid = getuid();
    info->gid = getgid();
    
    errno = 0;
    info->nice = getpriority(PRIO_PROCESS, 0);
    if (errno != 0) info->nice = 0;
    
    info->policy = sched_getscheduler(0);
    
    read_proc_stat(info);
    read_proc_status(info);
    
    // Get resource limits
    getrlimit(RLIMIT_CPU, &info->rlim_cpu);
    getrlimit(RLIMIT_FSIZE, &info->rlim_fsize);
    getrlimit(RLIMIT_NOFILE, &info->rlim_nofile);
    getrlimit(RLIMIT_STACK, &info->rlim_stack);
    
    // Get working directory
    if (getcwd(info->cwd, sizeof(info->cwd)) == NULL) {
        strcpy(info->cwd, "Unknown");
    }
    
    // Get hostname
    gethostname(info->hostname, sizeof(info->hostname));
}

// Clear screen
void clear_screen() {
    printf("\033[2J\033[H");
}

// Print header
void print_header() {
    printf(BRIGHT_CYAN BOLD);
    printf("\n");
    printf("  ███████╗██╗   ██╗███████╗    ███╗   ███╗ ██████╗ ███╗   ██╗\n");
    printf("  ██╔════╝╚██╗ ██╔╝██╔════╝    ████╗ ████║██╔═══██╗████╗  ██║\n");
    printf("  ███████╗ ╚████╔╝ ███████╗    ██╔████╔██║██║   ██║██╔██╗ ██║\n");
    printf("  ╚════██║  ╚██╔╝  ╚════██║    ██║╚██╔╝██║██║   ██║██║╚██╗██║\n");
    printf("  ███████║   ██║   ███████║    ██║ ╚═╝ ██║╚██████╔╝██║ ╚████║\n");
    printf("  ╚══════╝   ╚═╝   ╚══════╝    ╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═══╝\n");
    printf(RESET);
    printf(BRIGHT_YELLOW "  System Process Monitor & Configuration Tool\n" RESET);
    printf(DIM "  ────────────────────────────────────────────────────────────\n" RESET);
}

// Format limit value
void format_limit(rlim_t limit, char* buffer, size_t size) {
    if (limit == RLIM_INFINITY) {
        snprintf(buffer, size, "unlimited");
    } else {
        snprintf(buffer, size, "%lu", (unsigned long)limit);
    }
}

// Print process information
void print_process_info(ProcessInfo* info) {
    const char* policy_name;
    const char* state_desc;
    char cpu_limit[64], fsize_limit[64], nofile_limit[64], stack_limit[64];
    
    switch(info->policy) {
        case SCHED_OTHER: policy_name = "NORMAL"; break;
        case SCHED_FIFO: policy_name = "RT-FIFO"; break;
        case SCHED_RR: policy_name = "RT-RR"; break;
        case SCHED_BATCH: policy_name = "BATCH"; break;
        case SCHED_IDLE: policy_name = "IDLE"; break;
        default: policy_name = "UNKNOWN"; break;
    }
    
    switch(info->state) {
        case 'R': state_desc = "Running"; break;
        case 'S': state_desc = "Sleeping"; break;
        case 'D': state_desc = "Disk Sleep"; break;
        case 'Z': state_desc = "Zombie"; break;
        case 'T': state_desc = "Stopped"; break;
        default: state_desc = "Unknown"; break;
    }
    
    format_limit(info->rlim_cpu.rlim_cur, cpu_limit, sizeof(cpu_limit));
    format_limit(info->rlim_fsize.rlim_cur, fsize_limit, sizeof(fsize_limit));
    format_limit(info->rlim_nofile.rlim_cur, nofile_limit, sizeof(nofile_limit));
    format_limit(info->rlim_stack.rlim_cur, stack_limit, sizeof(stack_limit));
    
    printf("\n");
    
    // Process Identity Section
    printf(BRIGHT_MAGENTA "  ┌─ PROCESS IDENTITY ─────────────────────────────────────┐\n" RESET);
    printf("  │ " BRIGHT_GREEN "PID:" RESET " %-12d " BRIGHT_GREEN "PPID:" RESET " %-12d " BRIGHT_GREEN "State:" RESET " %-8s │\n", 
           info->pid, info->ppid, state_desc);
    printf("  │ " BRIGHT_GREEN "PGID:" RESET " %-11d " BRIGHT_GREEN "SID:" RESET " %-13d " BRIGHT_GREEN "Threads:" RESET " %-5ld │\n", 
           info->pgid, info->sid, info->num_threads);
    printf("  │ " BRIGHT_GREEN "UID:" RESET " %-12d " BRIGHT_GREEN "GID:" RESET " %-32d │\n", 
           info->uid, info->gid);
    printf("  │ " BRIGHT_GREEN "Host:" RESET " %-51s │\n", info->hostname);
    printf("  └────────────────────────────────────────────────────────────┘\n");
    
    // Scheduling Section
    printf(BRIGHT_BLUE "  ┌─ SCHEDULING ────────────────────────────────────────────┐\n" RESET);
    printf("  │ " BRIGHT_YELLOW "Policy:" RESET " %-17s " BRIGHT_YELLOW "Priority:" RESET " %-14d │\n", 
           policy_name, info->priority);
    printf("  │ " BRIGHT_YELLOW "Nice:" RESET " %-19d " BRIGHT_YELLOW "CPU User:" RESET " %-13lu │\n", 
           info->nice, info->utime);
    printf("  │ " BRIGHT_YELLOW "CPU System:" RESET " %-44lu │\n", info->stime);
    printf("  └────────────────────────────────────────────────────────────┘\n");
    
    // Memory Section
    printf(BRIGHT_CYAN "  ┌─ MEMORY ────────────────────────────────────────────────┐\n" RESET);
    printf("  │ " BRIGHT_WHITE "Virtual Size:" RESET " %-22lu bytes │\n", info->vsize);
    printf("  │ " BRIGHT_WHITE "Resident Set:" RESET " %-22ld pages │\n", info->rss);
    printf("  └────────────────────────────────────────────────────────────┘\n");
    
    // Resource Limits Section
    printf(BRIGHT_YELLOW "  ┌─ RESOURCE LIMITS ───────────────────────────────────────┐\n" RESET);
    printf("  │ " WHITE "CPU Time:" RESET " %-47s │\n", cpu_limit);
    printf("  │ " WHITE "Max File Size:" RESET " %-42s │\n", fsize_limit);
    printf("  │ " WHITE "Open Files:" RESET " %-45s │\n", nofile_limit);
    printf("  │ " WHITE "Stack Size:" RESET " %-45s │\n", stack_limit);
    printf("  └────────────────────────────────────────────────────────────┘\n");
    
    // Environment Section
    printf(BRIGHT_GREEN "  ┌─ ENVIRONMENT ───────────────────────────────────────────┐\n" RESET);
    printf("  │ " CYAN "Working Dir:" RESET "\n");
    printf("  │ %s\n", info->cwd);
    printf("  └────────────────────────────────────────────────────────────┘\n");
}

// Modify nice value
int modify_nice(int new_nice) {
    if (new_nice < -20 || new_nice > 19) {
        printf(RED "  ✗ Nice value must be between -20 and 19\n" RESET);
        return -1;
    }
    
    if (setpriority(PRIO_PROCESS, 0, new_nice) == -1) {
        printf(RED "  ✗ Failed to set nice value: %s\n" RESET, strerror(errno));
        printf(YELLOW "  ℹ Lowering nice (increasing priority) requires root\n" RESET);
        return -1;
    }
    
    printf(GREEN "  ✓ Nice value changed to: %d\n" RESET, new_nice);
    return 0;
}

// Modify scheduling policy
int modify_sched_policy(int policy, int priority) {
    struct sched_param param;
    param.sched_priority = priority;
    
    if (sched_setscheduler(0, policy, &param) == -1) {
        printf(RED "  ✗ Failed to set scheduling policy: %s\n" RESET, strerror(errno));
        printf(YELLOW "  ℹ Real-time policies require root privileges\n" RESET);
        return -1;
    }
    
    printf(GREEN "  ✓ Scheduling policy changed successfully\n" RESET);
    return 0;
}

// Modify resource limit
int modify_resource_limit(int resource, rlim_t new_limit) {
    struct rlimit rl;
    
    if (getrlimit(resource, &rl) == -1) {
        printf(RED "  ✗ Failed to get current limit\n" RESET);
        return -1;
    }
    
    rl.rlim_cur = new_limit;
    
    if (setrlimit(resource, &rl) == -1) {
        printf(RED "  ✗ Failed to set limit: %s\n" RESET, strerror(errno));
        return -1;
    }
    
    printf(GREEN "  ✓ Resource limit updated successfully\n" RESET);
    return 0;
}

// Change working directory
int modify_working_directory(const char* path) {
    if (chdir(path) == -1) {
        printf(RED "  ✗ Failed to change directory: %s\n" RESET, strerror(errno));
        return -1;
    }
    
    printf(GREEN "  ✓ Working directory changed to: %s\n" RESET, path);
    return 0;
}

// Interactive menu
void interactive_menu() {
    ProcessInfo info;
    int choice;
    
    while (1) {
        clear_screen();
        print_header();
        get_process_info(&info);
        print_process_info(&info);
        
        printf("\n");
        printf(BRIGHT_MAGENTA "  ┌─ ACTIONS ───────────────────────────────────────────────┐\n" RESET);
        printf("  │ " BRIGHT_WHITE "1." RESET " Modify Nice Value          " BRIGHT_WHITE "2." RESET " Change Scheduling     │\n");
        printf("  │ " BRIGHT_WHITE "3." RESET " Set CPU Time Limit         " BRIGHT_WHITE "4." RESET " Set File Size Limit   │\n");
        printf("  │ " BRIGHT_WHITE "5." RESET " Set Open Files Limit       " BRIGHT_WHITE "6." RESET " Change Directory      │\n");
        printf("  │ " BRIGHT_WHITE "7." RESET " Allocate Memory            " BRIGHT_WHITE "8." RESET " Create Child Process  │\n");
        printf("  │ " BRIGHT_WHITE "9." RESET " Send Signal                " BRIGHT_WHITE "0." RESET " Exit                  │\n");
        printf("  └────────────────────────────────────────────────────────────┘\n");
        printf(BRIGHT_CYAN "\n  → " RESET);
        
        if (scanf("%d", &choice) != 1) {
            while (getchar() != '\n');
            printf(RED "  ✗ Invalid input!\n" RESET);
            sleep(1);
            continue;
        }
        
        switch (choice) {
            case 1: {
                int value;
                printf(YELLOW "\n  Current nice: %d\n" RESET, info.nice);
                printf(CYAN "  Enter new nice (-20 to 19): " RESET);
                scanf("%d", &value);
                modify_nice(value);
                printf(DIM "\n  Press Enter..." RESET);
                getchar(); getchar();
                break;
            }
            
            case 2: {
                int policy, priority = 0;
                printf(YELLOW "\n  Policies: " RESET "0=NORMAL 1=FIFO 2=RR 3=BATCH 5=IDLE\n");
                printf(CYAN "  Enter policy: " RESET);
                scanf("%d", &policy);
                
                if (policy == SCHED_FIFO || policy == SCHED_RR) {
                    printf(CYAN "  Enter priority (1-99): " RESET);
                    scanf("%d", &priority);
                }
                
                modify_sched_policy(policy, priority);
                printf(DIM "\n  Press Enter..." RESET);
                getchar(); getchar();
                break;
            }
            
            case 3: {
                unsigned long value;
                printf(CYAN "  Enter CPU time limit (seconds, 0=unlimited): " RESET);
                scanf("%lu", &value);
                modify_resource_limit(RLIMIT_CPU, value == 0 ? RLIM_INFINITY : value);
                printf(DIM "\n  Press Enter..." RESET);
                getchar(); getchar();
                break;
            }
            
            case 4: {
                unsigned long value;
                printf(CYAN "  Enter max file size (bytes, 0=unlimited): " RESET);
                scanf("%lu", &value);
                modify_resource_limit(RLIMIT_FSIZE, value == 0 ? RLIM_INFINITY : value);
                printf(DIM "\n  Press Enter..." RESET);
                getchar(); getchar();
                break;
            }
            
            case 5: {
                unsigned long value;
                printf(CYAN "  Enter max open files (0=unlimited): " RESET);
                scanf("%lu", &value);
                modify_resource_limit(RLIMIT_NOFILE, value == 0 ? RLIM_INFINITY : value);
                printf(DIM "\n  Press Enter..." RESET);
                getchar(); getchar();
                break;
            }
            
            case 6: {
                char path[PATH_MAX];
                printf(CYAN "  Enter new directory path: " RESET);
                scanf("%s", path);
                modify_working_directory(path);
                printf(DIM "\n  Press Enter..." RESET);
                getchar(); getchar();
                break;
            }
            
            case 7: {
                int mb;
                printf(CYAN "  Enter MB to allocate (1-500): " RESET);
                scanf("%d", &mb);
                
                if (mb > 0 && mb < 500) {
                    size_t size = mb * 1024 * 1024;
                    char* mem = malloc(size);
                    if (mem) {
                        memset(mem, 1, size);
                        printf(GREEN "  ✓ Allocated %d MB\n" RESET, mb);
                        sleep(2);
                        free(mem);
                        printf(GREEN "  ✓ Memory freed\n" RESET);
                    } else {
                        printf(RED "  ✗ Allocation failed\n" RESET);
                    }
                }
                printf(DIM "\n  Press Enter..." RESET);
                getchar(); getchar();
                break;
            }
            
            case 8: {
                pid_t pid = fork();
                if (pid == 0) {
                    printf(GREEN "  ✓ Child process created (PID: %d)\n" RESET, getpid());
                    sleep(3);
                    exit(0);
                } else if (pid > 0) {
                    printf(GREEN "  ✓ Forked child with PID: %d\n" RESET, pid);
                } else {
                    printf(RED "  ✗ Fork failed\n" RESET);
                }
                printf(DIM "\n  Press Enter..." RESET);
                getchar(); getchar();
                break;
            }
            
            case 9: {
                int sig;
                printf(YELLOW "\n  Signals: " RESET "USR1=%d USR2=%d STOP=%d CONT=%d\n", 
                       SIGUSR1, SIGUSR2, SIGSTOP, SIGCONT);
                printf(CYAN "  Enter signal number: " RESET);
                scanf("%d", &sig);
                
                if (kill(getpid(), sig) == 0) {
                    printf(GREEN "  ✓ Signal sent\n" RESET);
                } else {
                    printf(RED "  ✗ Failed: %s\n" RESET, strerror(errno));
                }
                printf(DIM "\n  Press Enter..." RESET);
                getchar(); getchar();
                break;
            }
            
            case 0:
                clear_screen();
                printf(BRIGHT_CYAN "\n  Goodbye!\n\n" RESET);
                return;
                
            default:
                printf(RED "\n  ✗ Invalid choice!\n" RESET);
                sleep(1);
        }
    }
}

int main() {
    interactive_menu();
    return 0;
}