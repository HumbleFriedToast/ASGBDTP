#!/bin/bash

# Build script for PCB Monitor Project
# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}          PCB Monitor - Build Script${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
echo ""

# Configuration
CC="gcc"
CFLAGS="-Wall -Wextra -O2"
LIB_FILE="rootkitlib.c"
INSTALLER_FILE="installer.c"
APP_FILE="residentapp.c"

# Output files
LIB_OUT="rootkitlib.so"
INSTALLER_OUT="installer"
APP_OUT="residentapp"

# Function to check if file exists
check_file() {
    if [ ! -f "$1" ]; then
        echo -e "${RED}✗ Error: File '$1' not found!${NC}"
        return 1
    fi
    echo -e "${GREEN}✓ Found: $1${NC}"
    return 0
}

# Function to compile
compile() {
    local source=$1
    local output=$2
    local extra_flags=$3
    
    echo -e "${YELLOW}Compiling: $source → $output${NC}"
    
    if $CC $CFLAGS $extra_flags -o "$output" "$source" 2>&1; then
        echo -e "${GREEN}✓ Successfully compiled: $output${NC}"
        return 0
    else
        echo -e "${RED}✗ Failed to compile: $source${NC}"
        return 1
    fi
}

# Check for required files
echo -e "${BLUE}Checking source files...${NC}"
MISSING_FILES=0

if ! check_file "$LIB_FILE"; then
    MISSING_FILES=1
fi

if ! check_file "$INSTALLER_FILE"; then
    MISSING_FILES=1
fi

if ! check_file "$APP_FILE"; then
    MISSING_FILES=1
fi

if [ $MISSING_FILES -eq 1 ]; then
    echo ""
    echo -e "${RED}Build aborted: Missing required source files${NC}"
    exit 1
fi

echo ""
echo -e "${BLUE}Starting compilation...${NC}"
echo ""

# Clean old builds
echo -e "${YELLOW}Cleaning old builds...${NC}"
rm -f "$LIB_OUT" "$INSTALLER_OUT" "$APP_OUT"
echo -e "${GREEN}✓ Clean complete${NC}"
echo ""

# Compile shared library
if ! compile "$LIB_FILE" "$LIB_OUT" "-shared -fPIC -ldl"; then
    echo -e "${RED}Build failed!${NC}"
    exit 1
fi
echo ""

# Compile installer
if ! compile "$INSTALLER_FILE" "$INSTALLER_OUT" ""; then
    echo -e "${RED}Build failed!${NC}"
    exit 1
fi
echo ""

# Compile application
if ! compile "$APP_FILE" "$APP_OUT" ""; then
    echo -e "${RED}Build failed!${NC}"
    exit 1
fi
echo ""

# Make files executable
chmod +x "$INSTALLER_OUT" "$APP_OUT"

# Summary
echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}✓ Build Complete!${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
echo ""
echo "Built files:"
echo -e "  ${GREEN}•${NC} $LIB_OUT       (Shared library)"
echo -e "  ${GREEN}•${NC} $INSTALLER_OUT (Installer program)"
echo -e "  ${GREEN}•${NC} $APP_OUT       (PCB Monitor application)"
echo ""
echo "Next steps:"
echo -e "  ${YELLOW}1.${NC} Install: ${BLUE}sudo ./$INSTALLER_OUT${NC}"
echo -e "  ${YELLOW}2.${NC} Run app: ${BLUE}/opt/myapp/$APP_OUT${NC}"
echo -e "  ${YELLOW}   or:${NC}      ${BLUE}sudo /opt/myapp/$APP_OUT${NC} (for full privileges)"
echo ""
echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"